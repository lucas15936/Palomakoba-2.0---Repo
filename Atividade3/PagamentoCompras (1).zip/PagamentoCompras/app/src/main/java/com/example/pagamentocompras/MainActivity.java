
package com.example.pagamentocompras;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
//  import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    // o AppCompatActivity serve para aplicar códigos novos em androids antigos, basicamente

    CheckBox ckarroz, ckcarne, ckpao, ckleite, ckovo;
    Button btntotal;
    double valor;
    RadioButton rn, r5, r10, r15;
    RadioGroup rgrupo;
    EditText pago;
    Button btncalcula;
    TextView tvalor;
    String tvalor2;
    double valor1;
    String desconto;
    double troco1;
    String spago;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ckarroz = findViewById(R.id.ckarroz);
        ckcarne = findViewById(R.id.ckcarne);
        ckpao = findViewById(R.id.ckpao);
        ckleite = findViewById(R.id.ckleite);
        ckovo = findViewById(R.id.ckovo);
        // TextView tvalor = findViewById(R.id.tvalor);
        tvalor = findViewById(R.id.tvalor);
        rn = findViewById(R.id.rn);
        r5 = findViewById(R.id.r5);
        r10 = findViewById(R.id.r10);
        r15 = findViewById(R.id.r15);
        rgrupo = findViewById(R.id.rgrupo);
        pago = findViewById(R.id.pago);

        btntotal = findViewById(R.id.btntotal);
        btncalcula = findViewById(R.id.btncalcula);

        btntotal.setOnClickListener(new View.OnClickListener() {
            // TextView tvalor = (TextView)findViewById(R.id.tvalor);

            @Override
            public void onClick(View v) {
                valor = 0;
                if (ckarroz.isChecked()){
                    valor += 3.5;}
                if (ckcarne.isChecked()){
                    valor += 12.3;}
                if (ckpao.isChecked()){
                    valor += 2.2;}
                if (ckleite.isChecked()){
                    valor += 5.5;}
                if (ckovo.isChecked()){
                    valor += 7.5;}

                tvalor2 = Double.toString(valor);
                tvalor.setText(tvalor2);
            }
        });


        btncalcula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){



                int opcao = rgrupo.getCheckedRadioButtonId();

                if (opcao == R.id.rn) {
                    valor1 = valor; desconto = "0%";
                }
                else if (opcao == R.id.r5) {
                    valor1 = 0.95*valor; desconto = "5%";
                }
                else if (opcao == R.id.r10) {
                    valor1 = 0.90*valor; desconto = "10%";
                }
                else if (opcao == R.id.r15) {
                    valor1 = 0.85*valor; desconto = "15%";
                }

                EditText pago = (EditText) findViewById(R.id.pago);
                spago = pago.getText().toString();

                if (tvalor.getText().toString().equals("")) {
                    AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
                    alerta.setTitle("Aviso");
                    String msg2 = "Aperte o botão total.";
                    alerta.setMessage(msg2);
                    alerta.setNeutralButton("OK", null);
                    alerta.show();
                    return;
                }

                if (spago.matches("")) {
                    AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
                    alerta.setTitle("Aviso");
                    String msg2 = "Valor pago pelo cliente não digitado.";
                    alerta.setMessage(msg2);
                    alerta.setNeutralButton("OK", null);
                    alerta.show();
                    return;
                }

                double pago1 = Double.parseDouble(pago.getText().toString());
                String pago5 = pago.getText().toString();


                if (pago1 > valor1) {
                    troco1 = pago1 - valor1;

                    AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
                    alerta.setTitle("Aviso");



                    @SuppressLint("DefaultLocale") String msg = String.format(
                            "\nValor total da compra = %5.2f." +
                            "\nValor com desconto = %5.2f" +
                            "\nDesconto: %s." +
                            "\nValor pago: %s." +
                            "\nTroco = %5.2f", valor, valor1, desconto, pago5, troco1);

                    alerta.setMessage(msg);
                    alerta.setIcon(R.drawable.compras2);
                    alerta.setNeutralButton("OK", null);
                    alerta.show();

                }


                else {
                    AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
                    alerta.setTitle("Aviso");
                    String msg2 = "Valor insuficiente para o pagamento.";
                    alerta.setMessage(msg2);
                    alerta.setNeutralButton("OK", null);
                    alerta.show();
                }





            }
        });

    }
}

