package com.example.all_in;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.all_in.databinding.ActivityMapaBinding;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;


public class Mapa extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapaBinding binding;
    private String[] permissoes = new String[]{Manifest.permission.ACCESS_FINE_LOCATION};
    private String abrirmapa;
    private LocationManager locationManager;
    private LocationListener locationListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Permissoes.validarPermissoes(permissoes, this, 1);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Bundle params = getIntent().getExtras();

        if (params != null) {
            abrirmapa = params.getString("texto");

        }


//            Vou comentar essas 2 linhas
//        binding = ActivityMapaBinding.inflate(getLayoutInflater());
//        setContentView(binding.getRoot());

//        Vou comentar essas 4 linhas
//        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
//        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
//                .findFragmentById(R.id.map);
//        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    abrirmapa.setOnQueryListener(new )
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                Log.d("Localização", "onLocationChanged" + abrirmapa);





//                Double latitude = abrirmapa.getLatitude();
//                Double longitude = abrirmapa.getLongitude();
//                mMap.clear();
//                LatLng localUsuario = new LatLng(latitude, abrirmapa.);
//                mMap.addMarker(new MarkerOptions().position(localUsuario).title("Estou aqui!"));
//                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(localUsuario, 15));

                Geocoder geocoder = new Geocoder(Mapa.this);
                try {
                    List<Address> listaEndereco = geocoder.getFromLocationName(abrirmapa, 1);
                    if (listaEndereco != null && listaEndereco.size() > 0) {
                        Address endereco = listaEndereco.get(0);
                        LatLng latLng = new LatLng(endereco.getLatitude(), endereco.getLongitude());
                        mMap.addMarker(new MarkerOptions().position(latLng).title(abrirmapa));
                        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
//                        Log.d("Endereço", "onLocationChanged" + endereco.toString());


                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };


    }

}