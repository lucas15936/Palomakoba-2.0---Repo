package com.example.all_in;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.all_in.api.CEPService;
import com.example.all_in.model.CEP;

import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {

    private Button botaoCEP;
    private Button botaoVer;
    private EditText edtCEP;
    private Retrofit retrofit;
    private TextView textoResultado;
    private String [] permissoes = new String[] {
            Manifest.permission.ACCESS_FINE_LOCATION
    };

    private String logra1;
    private String bairro1;
    private String local1;

    private String cepaqui;

    private TextView cep1;
    private TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Permissoes.validarPermissoes(permissoes, this, 1);

        botaoCEP = findViewById(R.id.botaoCEP);
        edtCEP = findViewById(R.id.edtCEP);
        textoResultado = findViewById(R.id.textoResultado);
        botaoVer = findViewById(R.id.botaoVer);
        textView1 = findViewById(R.id.textView1);

        String urlCep = "https://viacep.com.br/ws/";
        retrofit = new Retrofit.Builder()
                .baseUrl(urlCep)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        botaoCEP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    recuperarCep();
                    getCoordinates(view);


            }



        });

        botaoVer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                verMapa();

            }





        });


    }

//    private void recuperarCep() {

            private void recuperarCep() {
                CEPService cepService = retrofit.create(CEPService.class);
                String cep = edtCEP.getText().toString();
                Call<CEP> call = cepService.recuperarCEP(cep);
                call.enqueue(new Callback<CEP>() {



                    @Override
                    public void onResponse(Call<CEP> call, Response<CEP> response) {

                        if (response.isSuccessful()) {
                            CEP cep = response.body();

                            logra1 =  cep.getLogradouro();
                            bairro1 = cep.getBairro();
                            local1 = cep.getLocalidade();



                                if (logra1 != null) {
                                    textoResultado.
                                            setText(cep.getLogradouro() + "/" + cep.getBairro() + "/" + cep.getLocalidade());


                                }
                                else {

                                    textoResultado.setText("");
                                    AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
                                    alerta.setTitle("Aviso");
                                    String aviso2 = "CEP inválido.";
                                    alerta.setMessage(aviso2);
                                    alerta.setNeutralButton("OK", null);
                                    alerta.show();
                                    return;


                                }

                                cepaqui = logra1 + "Bairro" + bairro1 + "Cidade" + local1 ;

                            Intent it = new Intent(getBaseContext(), Mapa.class);
                            Bundle params = new Bundle();
                            params.putString("texto", cepaqui);
                            startActivity(it);









//                            textoResultado.
//                                    setText(cep.getLogradouro() + "/" + cep.getBairro() + "/" + cep.getLocalidade());
                        }
//                        else   Toast.makeText(getBaseContext(),response.errorBody().string(),Toast.LENGTH_SHORT).show();

//                        else {
//                            try {
//                                JSONObject jObjError = new JSONObject(response.errorBody().string());
//                                Toast.makeText(getBaseContext(), jObjError.getJSONObject("error").getString("message"), Toast.LENGTH_LONG).show();
//                            } catch (Exception e) {
//                                Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
//                            }
//                        }

                    }

                    @Override
                    public void onFailure(Call<CEP> call, Throwable t) {

                            }
                });








             }






            private void verMapa() {



//                AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
//                alerta.setTitle("Aviso");
//                String cep2 = cep1.getText().toString();
//                alerta.setMessage(cep2);
//                alerta.setNeutralButton("OK", null);
//                alerta.show();
//                return;





            }







    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        for (int permissaoResultado : grantResults){
            if(permissaoResultado == PackageManager.PERMISSION_DENIED){
                alertaValidacao();
            }else if (permissaoResultado == PackageManager.PERMISSION_GRANTED){
                return;
            }
        }
    }


    private void alertaValidacao(){
        AlertDialog.Builder alerta = new AlertDialog.Builder(getApplicationContext());
        alerta.setTitle("Permissões negadas!");
        alerta.setMessage("Para utilizar o app é necessário aceitar as permissões!");
        alerta.setCancelable(false);
        alerta.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                finish();
            }
        });
        alerta.create().show();
    }

//
//    public void getCoordinates(View view){

    private void getCoordinates(View view){
        Geocoder geocoder = new Geocoder(this);
        List<Address> addressList;

        recuperarCep();


        cepaqui = logra1 + "Bairro" + bairro1 + "Cidade" + local1;

//        if (logra1 != null) {
            try {
                addressList = geocoder.getFromLocationName(cepaqui, 1);



                if (logra1 != null) {
                    double doubleLat = addressList.get(0).getLatitude();
                    double doubleLong = addressList.get(0).getLongitude();

                    textView1.setText("Latitude: " + String.valueOf(doubleLat) + " | " + "Longitude: " +
                            String.valueOf(doubleLong));



                }

                else { textView1.setText(logra1);
/*////                AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this);
////                alerta.setTitle("Aviso");
////                String aviso2 = "CEP inválido.";
////                alerta.setMessage(aviso2);
////                alerta.setNeutralButton("OK", null);
////                alerta.show();*/
                return;
               }
            } catch (IOException e) {
                e.printStackTrace();
            }

//        }

//        else {
//            return;
//        }

    }















    }

