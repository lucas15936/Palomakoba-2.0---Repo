package com.example.all_in;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.all_in.R;
import com.example.all_in.model.CEP;

import java.util.ArrayList;
import java.util.List;

public class adapter extends RecyclerView.Adapter<DadoAdpater.MyViewHolder> {

    private List<Dado> dados = new ArrayList<Dado>();

    public DadoAdpater(List<Dado> lista){
        this.dados = lista;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemLista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.dados_adapter_view, parent, false);

        return new MyViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.nomeRua.setText(this.dados.get(position).getLogradouro());
        holder.nomeBairro.setText(this.dados.get(position).getBairro());
        holder.nomeCidade.setText(this.dados.get(position).getLocalidade());
    }

    @Override
    public int getItemCount() {
        return this.dados.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView nomeContato, email, telefone;

        public MyViewHolder(@NonNull View itemView) {

            TextView nomeRua, nomeBairro, nomeCidade;
            nomeRua = itemView.findViewById(R.id.txtNome);
            nomeBairro = itemView.findViewById(R.id.txtEmail);
            nomeCidade = itemView.findViewById(R.id.txtTelefone);
        }
    }

}