package com.example.all_in;

public interface IDadoDAO {
    public boolean salvar(Dado dado);
    public boolean atualizar(Dado dado);
    public boolean deletar(Dado dado);
    public List<Dado> listar();
}
