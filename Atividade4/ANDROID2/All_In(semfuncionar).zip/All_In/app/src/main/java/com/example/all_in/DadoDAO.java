package com.example.all_in;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

import com.example.all_in.api.CEPService;

import java.util.List;

public class DadoDAO implements IDadoDAO{
    private SQLiteDatabase leitura;
    private SQLiteDatabase escrita;

    public DadoDAO(Context context) {
        DbHelper dbHelper = new DbHelper(context);
        leitura = dbHelper.getReadableDatabase();
        escrita = dbHelper.getWritableDatabase()
    }
    @Override
    public boolean salvar(Dado dado){
        ContentValues contentValues = new ContentValues();
        contentValues.put("nomeRua", dado.getLogradouro());
        contentValues.put("nomeBairro", CEPService.getBairro());
        contentValues.put("nomeCidade", dado.getLocalidade());
        this.escrita.insert(DbHelper.TABELA_DADOS, null, contentValues);
        return true;
    }

    @Override
    public boolean atualizar(Dado dado) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("nomeRua", dado.getLogradouro());
        contentValues.put("nomeBairro", CEPService.getBairro());
        contentValues.put("nomeCidade", dado.getLocalidade());
        String [] args = {String.valueOf(dado.getId())};
        this.escrita.update(DbHelper.TABELA_DADOS, contentValues, "id=?", args);
        return true;
    }

    @Override
    public boolean deletar(Dado dado) {
        String [] args = {String.valueOf(dado.getId())};
        this.escrita.delete(DbHelper.TABELA_DADOS, "id=?", args);
        return true;
    }

    @SupressLint("Range")
    @Override
    public List<Dado> listar() {
        List<Dado> dados = new ArrayList<>();
        String sql = "SELECT * FROM " + DbHelper.TABELA_DADOS + ";";
        Cursor cursos = leitura.rawQuery(sql, null);
        while(cursor.moveToNext()){
            Long id = cursor.getLong(cursor.getColumnIndex("id"));
            String nomeRua = cursor.getString(cursor.getColumnIndex("nomeRua"));
            String nomeBairro = cursor.getString(cursor.getColumnIndex("nomeBairro"));
            String nomeCidade = cursor.getString(cursor.getColumnIndex("nomeCidade"));
            dados.add(new Dado(nomeRua, nomeBairro, nomeCidade));
        }
        return dados;
    }
}
