
package com.example.all_in.model;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

import com.example.all_in.helper.DadoDAO;
import com.example.all_in.model.CEP;

import com.example.all_in.R;
import com.google.android.material.textfield.TextInputEditText;

public class dados extends AppCompatActivity {

//    activity

   private TextInputEditText nomeRua, nomeBairro, nomeCidade;
   private Dados dadoAtual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dados);

       nomeRua = findViewById(R.id.edtNomeContato);
       nomeBairro = findViewById(R.id.edtTelefone);
       nomeCidade = findViewById(R.id.edtEmail);
       Intent intent = getIntent();
       dadoAtual = (Dados) intent.getSerializableExtra("dadoSelecionado");
       if (dadoAtual != null){
           nomeRua.setText(dadoAtual.getLogradouro());
           nomeBairro.setText(dadoAtual.getBairro());
           nomeCidade.setText(dadoAtual.getLocalidade());

       }

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_dados);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.OnCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.itemSalver:
                DadoDAO dadoDAO = new DadoDAO(getApplicationContext());
                if (dadoAtual != null) {
                    String rua = nomeRua.getText().toString();
                    String bairro = nomeBairro.getText().toString();
                    String cidade = nomeCidade.getText().toString();
                    Long id = dadoAtual.getId();
                    Dado dado = new Dado(rua, bairro, cidade);
                    if (dadoDAO.atualizar(dado)) {
                        Toast.makeText(getApplicationContext(), "Endereço atualizado!",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    }
                     else {
                    Toast.makeText(getApplicationContext(), "Erro ao atualizar o endereço!",
                            Toast.LENGTH_SHORT).show();
                }
        } else {
                    String rua = nomeRua.getText().toString();
                    String bairro = nomeBairro.getText().toString();
                    String cidade = nomeCidade.getText().toString();
                    Dado dado = new Dado();
                    dado.setLogradouro(rua);
                    dado.setBairro(bairro);
                    dado.setLocalidade(cidade);
                    if (dadoDAO.salvar(dado)) {
                        Toast.makeText(getApplicationContext(), "Contato salvo!",
                                Toast.LENGTH_SHORT).show();
                        finish();

                    } else {
                        Toast.makeText(getApplicationContext(), "Erro ao salvar dado!",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                break;
    }
    return super.onOptionsItemSelected(item);

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_dados);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
